# -*- coding: utf-8 -*-
from caches.base_cache import connect_database
# from modules.kodi_utils import logger

INSERT_ONE = 'INSERT OR REPLACE INTO resolved VALUES (?, ?, ?, ?, ?)'
DELETE_ONE = 'DELETE FROM resolved where id=?'
SELECT_TYPE = 'SELECT * FROM resolved WHERE db_type == ?'
DELETE_TYPE = 'DELETE FROM resolved WHERE db_type=?'

class ResolvedCache:
	def insert_one(self, db_type, tmdb_id, season, episode, data):
		dbcon = connect_database('resolved_db')
		dbcon.execute(INSERT_ONE, (db_type, tmdb_id, season, episode, data))

	def delete_one(self, _id):
		dbcon = connect_database('resolved_db')
		dbcon.execute(DELETE_ONE, (_id,))
		dbcon.execute('VACUUM')

	def clear_cache(self, db_type):
		dbcon = connect_database('resolved_db')
		dbcon.execute(DELETE_TYPE, (db_type,))
		dbcon.execute('VACUUM')

resolved_cache = ResolvedCache()
